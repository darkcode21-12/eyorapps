Run the Bat file  before starting

